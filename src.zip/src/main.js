import 'core-js/stable'
import Vue from 'vue'
import App from './App'
import router from './router/index'
import CoreuiVue from '@coreui/vue'
import { iconsSet as icons } from './assets/icons/icons.js'
import store from './store'
import axios from 'axios'
import VueAxios from 'vue-axios'
import Toast from "vue-toastification"
import "vue-toastification/dist/index.css"
import i18n from './i18n'


Vue.config.performance = true
Vue.use(CoreuiVue)
Vue.prototype.$http = axios
Vue.prototype.$log = console.log.bind(console)


const token = localStorage.getItem('user-token')
if (token) {
  Vue.prototype.$http.defaults.headers.common['Authorization'] = token
}


Vue.use(Toast, {
  transition: "Vue-Toastification__fade",
  maxToasts: 3,
  newestOnTop: true,
  position: "top-right",
  timeout: 2000,
  closeOnClick: true,
  pauseOnFocusLoss: true,
  pauseOnHover: false,
  draggable: true,
  draggablePercent: 0.7,
  showCloseButtonOnHover: false,
  hideProgressBar: true,
  closeButton: "button",
  icon: true,
  rtl: false,
})


new Vue({
  i18n,
  el: '#app',
  router,
  store,
  icons,
  template: '<App/>',
  components: {
    App
  },

})
