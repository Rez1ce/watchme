<template>

      <CCard bodyWrapper>
                        <CSelect
                  placeholder="Name"
                  :options="input_name"
                  :value.sync="input_name_selected"
                  @change="fetch"
                />
          <CDataTable
            hover
            striped
            :loading="isLoading"
            :items="items"
            :fields="fields"
            :items-per-page="20"
            :no-items-view="null"
            :active-page="activePage"
            :pagination="{ doubleArrows: false, align: 'center' }"
            :sorter="{ external: false, resetable: false }"
            @page-change="pageChange"
          >
            <template #status="data">
              <td>
                <CBadge :color="getBadge(data.item.status)">
                  {{ data.item.status }}
                </CBadge>
              </td>
            </template>
            <template #no-items-view>
              <div></div>
            </template>
          </CDataTable>
      </CCard>

</template>

<script>
export default {
  name: "Users",
  
  data: ()  => ({
    input_name: [],
    input_name_selected: "",
    items: [],

    isLoading: false,
    activePage: 1,
  }),
  watch: {
    $route: {
      immediate: true,
      handler(route) {
        if (route.query && route.query.page) {
          this.activePage = Number(route.query.page);
        }
      },
    },
  },
  computed: {
      fields: vm =>[
      { key: "0", label: vm.$i18n.t("message.date"), _classes: "font-weight-bold" },
      { key: "1", label: vm.$i18n.t("message.startday") },
      { key: "2", label: vm.$i18n.t("message.endday") },
      { key: "3", label: vm.$i18n.t("message.activetime") },
      { key: "4", label: vm.$i18n.t("message.inactivetime") },

    ],
  },
  methods: {
    pageChange(val) {
      this.$router.push({ query: { page: val } });
    },
    fetch() {
      this.$http
      .get("http://10.5.37.89:8000/takename")
      .then((response) => {
        var temp = response.data.names;
        var temp_names = [];
        temp.forEach(function (item, i, arr) {
          temp_names[i] = item[0];
        });

        this.input_name = temp_names;
        //this.input_name_selected = temp_names[0];
      })
      .catch((error) => (this.err = error.response.data.detail));
      this.isLoading = true;
      this.$http
        .get("http://10.5.37.89:8000/items/justwork?name_req="+this.input_name_selected)
        .then((response) => {
          this.items = response.data.justwork;
        })
        .catch((error) => (this.err = error.response.data.detail))
        .finally(() => (this.isLoading = false));
    },
  },
  created() {
    this.fetch();
  },
};
</script>
