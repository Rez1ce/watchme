var app = new Vue({
  el: '#app',
  data: {
    name: '',
    date: '',
    active: '50%',
    nonactive: '50%',
    err: '',
    debug: 'debug on',
    good_time: '',
    bad_time: ''
  },
  methods: {
    getName(){
      var vm = this
      Vue.prototype.$axios = axios
        this.$axios.get("http://localhost:8000/items/sql", {
            params: {
                name_req: this.$refs.input_name.value,
                date_req: this.$refs.input_date.value
            }  
        })
        .then(function (response){
          vm.err = ''
          var temp = response.data.active
          var temp1 = response.data.nonactive
          vm.good_time = response.data.active
          vm.bad_time = response.data.nonactive
          temp = temp.split(":")
          temp1 = temp1.split(":")
          var act_sum = 0
          var nonact_sum = 0
          var sum = 0
          var act_res = 0
          var nonact_res = 0
          temp.forEach(function(entry) {
            entry = parseInt(entry, 10)
          });
          act_sum = (temp[0]*60*60) + (temp[1]*60) + parseInt(temp[2])
          temp1.forEach(function(entry) {
            entry = parseInt(entry, 10)
          });
          nonact_sum = (temp1[0]*60*60) + (temp1[1]*60) + parseInt(temp1[2])
          sum = parseInt(act_sum) + parseInt(nonact_sum)
          act_res = parseInt(((100*act_sum)/sum)+1)
          nonact_res = parseInt((100*nonact_sum)/sum)


          vm.active = act_res
          vm.nonactive = nonact_res

          var act_bar = document.getElementsByClassName("progress-bar bg-success")
          var nonact_bar = document.getElementsByClassName("progress-bar bg-danger")
          temp_act = act_bar[0].style
          temp_nonact = nonact_bar[0].style
          temp_act.cssText = "width: "+act_res+"%"
          temp_nonact.cssText = "width: "+nonact_res+"%"
        })
        .catch(error => (vm.err = error.response.data.detail, vm.active = '' ,vm.nonactive = ''))
    },

    splitString(stringToSplit, separator) {
      var arrayOfStrings = stringToSplit.split(separator);
      return arrayOfStrings
    },

    convertMinutesToTime(minutes) {
      function pad(n) {
          n = n.toString();
          n = n.length < 2 ? ("0" + n) : n;
          return n;
      }
      var paddedHours = pad(Math.floor(minutes / 60));
      var paddedMinutes = pad(minutes % 60);
  
      return paddedHours + ":" + paddedMinutes
  }

    }
})





