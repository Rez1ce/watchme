<template>
  <div>
    <CRow>
      <CCol md="8">
        <CCard>
          <CCardHeader>
            <CRow>
              <CCol md="5">
                <CSelect
                  placeholder="Name"
                  :options="input_name"
                  :value.sync="input_name_selected"
                />
              </CCol>
              <CCol md="5">
                <CInput type="Date" v-model="input_date"> </CInput>
              </CCol>
              <CCol>
                <CButton @click="clicked" color="primary">
                  {{ $t("message.buttchoose") }}
                </CButton>
              </CCol>
            </CRow>
          </CCardHeader>
          <CCardBody>
            <CProgress :max="100" class="mb-3">
              <CProgressBar
                color="gradient-success"
                :value="values[0]"
                show-percentage
              />
              <CProgressBar
                color="gradient-warning"
                :value="values[1]"
                show-percentage
              />
            </CProgress>

            <CCol>
              <CRow>
                <div
                  class="color-box pt-2 border mr-2"
                  style="width: 20px; height: 22px; background-color: #20a546"
                ></div>
                {{ $t("message.progressexplgood") }}
              </CRow>
            </CCol>
            <br />
            <CCol>
              <CRow>
                <div
                  class="color-box border mr-2"
                  style="width: 20px; height: 22px; background-color: #f69a0c"
                ></div>
                {{ $t("message.progressexplbad") }}
              </CRow>
            </CCol>
          </CCardBody>
        </CCard>
      </CCol>

      <CCol sm="4">
        <CCard v-if="show" body-wrapper>
          <CRow> {{ $t("message.startday") }}: {{ time_start }}</CRow>
          <CRow> {{ $t("message.endday") }}: {{ time_end }}</CRow>
          <CRow> {{ $t("message.activetime") }}: {{ good_time }}</CRow>
          <CRow> {{ $t("message.inactivetime") }}: {{ bad_time }}</CRow>
          <CRow> {{ $t("message.totalTime") }}: {{ total_time }}</CRow>
        </CCard>
      </CCol>
    </CRow>
    <CRow>
      <CCol>
        <CCard v-if="show">
          <CCardBody>
            <CTabs>
              <CTab active>
                <template slot="title">
                  <CIcon name="cil-chart-pie" /> {{ $t("message.processtime") }}
                </template>
                <CDataTable
                  hover
                  striped
                  fixed
                  :loading="isLoading"
                  :items="items2"
                  :fields="fields2"
                  :items-per-page="10"
                  :no-items-view="null"
                  :sorter="{ external: false, resetable: false }"
                  :active-page="activePage"
                  :pagination="{ doubleArrows: true, align: 'center' }"
                >
                  <template #no-items-view>
                    <div></div>
                  </template>
                </CDataTable>
              </CTab>
              <CTab>
                <template slot="title">
                  <CIcon name="cil-calculator" /> {{ $t("message.bizproc") }}
                </template>
                <CDataTable
                  hover
                  striped
                  :loading="isLoading"
                  :items="items1"
                  :fields="fields1"
                  :items-per-page="10"
                  :no-items-view="null"
                  :active-page="activePage"
                  :sorter="{ external: false, resetable: false }"
                  :pagination="{ doubleArrows: true, align: 'center' }"
                >
                  <template #no-items-view>
                    <div></div>
                  </template>
                </CDataTable>
              </CTab>
              <CTab>
                <template slot="title">
                  <CIcon name="cilList" /> {{ $t("message.activefeed") }}
                </template>
                <CDataTable
                  hover
                  striped
                  :loading="isLoading"
                  :items="items0"
                  :fields="fields0"
                  :items-per-page="10"
                  :no-items-view="null"
                  :sorter="{ external: false, resetable: false }"
                  :active-page="activePage"
                  :pagination="{ doubleArrows: true, align: 'center' }"
                >
                  <template #no-items-view>
                    <div></div>
                  </template>
                </CDataTable>
              </CTab>
            </CTabs>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  </div>
</template>

<script>
export default {
  name: "ProgressBars",
  data() {
    var date = new Date();
    var dd = date.getDate();
    if (dd < 10) dd = "0" + dd;
    var mm = date.getMonth() + 1;
    if (mm < 10) mm = "0" + mm;
    var yy = date.getFullYear();
    date = yy + "-" + mm + "-" + dd;
    var vm = this;
    this.$http
      .get("http://10.5.37.89:8000/takename")
      .then(function (response) {
        var temp = response.data.names;
        var temp_names = [];
        temp.forEach(function (item, i, arr) {
          temp_names[i] = item[0];
        });

        vm.input_name = temp_names;
        vm.input_name_selected = temp_names[0];
      })
      .catch((error) => (this.err = error.response.data.detail));

    return {
      show: false,
      values: [15, 30],
      info: "",
      good_time: "",
      bad_time: "",
      err: "",
      input_name: [],
      input_date: date,
      input_name_selected: "",
      time_start: "",
      time_end: "",
      total_time: "",
      color: ["#20a546", "#f69a0c"],

      items0: [],
      items1: [],
      items2: [],

      isLoading: false,
      activePage: 1,
    };
  },
  computed: {
    fields0: vm => [
      { key: "1", label: vm.$i18n.t("message.proc") },
      { key: "2", label: vm.$i18n.t("message.time") },
      { key: "3", label: vm.$i18n.t("message.condition") },
    ],
    fields1: vm => [
      { key: "0", label: vm.$i18n.t("message.proc") },
      { key: "2", label: vm.$i18n.t("message.time") },
      { key: "1", label: vm.$i18n.t("message.condition") },
    ],
    fields2: vm => [
      { key: "0", label: vm.$i18n.t("message.proc") },
      { key: "2", label: vm.$i18n.t("message.time") },
    ],
  },
  methods: {
    pageChange(val) {
      this.$router.push({ query: { page: val } });
    },
    showToast(mes) {
      this.$toast.error(mes);
    },
    clicked() {
      var vm = this;
      this.$http
        .get(
          "http://10.5.37.89:8000/items/sql?name_req=" +
            vm.input_name_selected +
            "&date_req=" +
            vm.input_date
        )
        .then(function (response) {
          vm.err = "";
          var temp = response.data.active;
          var temp1 = response.data.nonactive;
          vm.good_time = response.data.active;
          vm.bad_time = response.data.nonactive;
          vm.time_start = response.data.time_start.substr(0, 8);
          vm.time_end = response.data.time_end.substr(0, 8);
          let start_date = new Date(1970, 11, 17, response.data.time_start.substr(0,2), response.data.time_start.substr(3,2), response.data.time_start.substr(6,2));
          let end_date = new Date(1970, 11, 17, response.data.time_end.substr(0,2), response.data.time_end.substr(3,2), response.data.time_end.substr(6,2));
          let total = new Date(end_date - start_date);
          vm.total_time = String(total.getUTCHours() + ':' + total.getUTCMinutes() + ':' + total.getUTCSeconds());
          temp = temp.split(":");
          temp1 = temp1.split(":");
          var act_sum = 0;
          var nonact_sum = 0;
          var sum = 0;
          var act_res = 0;
          var nonact_res = 0;
          temp.forEach(function (entry) {
            entry = parseInt(entry, 10);
          });
          act_sum = temp[0] * 60 * 60 + temp[1] * 60 + parseInt(temp[2]);
          temp1.forEach(function (entry) {
            entry = parseInt(entry, 10);
          });
          nonact_sum = temp1[0] * 60 * 60 + temp1[1] * 60 + parseInt(temp1[2]);
          sum = parseInt(act_sum) + parseInt(nonact_sum);
          act_res = parseInt((100 * act_sum) / sum + 1);
          nonact_res = parseInt((100 * nonact_sum) / sum);

          if (act_res == 101) {
            act_res = act_res - 1;
          }

          if (nonact_res == 101) {
            nonact_res = nonact_res - 1;
          }

          vm.$set(vm.values, 0, parseInt(act_res));
          vm.$set(vm.values, 1, parseInt(nonact_res));
          vm.show = true;
        })
        .catch(
          (error) => (
            (vm.err = error.response.data.detail),
            (vm.values[0] = 0),
            (vm.values[1] = 0),
            vm.showToast(vm.err)
          )
        );

      this.$http
        .get(
          "http://10.5.37.89:8000/items/alldata?name_req=" +
            vm.input_name_selected +
            "&date_req=" +
            vm.input_date
        )
        .then(function (response) {
          vm.err = "";
          vm.items0 = response.data.alldata;
        })
        .catch(
          (error) => (
            (vm.err = error.response.data.detail), vm.showToast(vm.err)
          )
        );

      this.$http
        .get(
          "http://10.5.37.89:8000/items/pidwithhead?name_req=" +
            vm.input_name_selected +
            "&date_req=" +
            vm.input_date
        )
        .then(function (response) {
          vm.err = "";
          vm.items1 = response.data.pidata;
        })
        .catch(
          (error) => (
            (vm.err = error.response.data.detail), vm.showToast(vm.err)
          )
        );

      this.$http
        .get(
          "http://10.5.37.89:8000/items/onlypidinfo?name_req=" +
            vm.input_name_selected +
            "&date_req=" +
            vm.input_date
        )
        .then(function (response) {
          vm.err = "";
          vm.items2 = response.data.onlypid;
        })
        .catch(
          (error) => (
            (vm.err = error.response.data.detail), vm.showToast(vm.err)
          )
        );
    },
  },
};
</script>
