<template>
      <CCard bodyWrapper>
          <CDataTable
            hover
            striped
            :loading="isLoading"
            :items="items"
            :fields="fields"
            :items-per-page="20"
            :no-items-view="null"
            :active-page="activePage"
            :pagination="{ doubleArrows: false, align: 'center' }"
            @page-change="pageChange"
          >
            <template #storage_type="{ item }">
              <td>
                <CBadge :color="getBadge(item.storage_type)">{{
                  item.storage_type
                }}</CBadge>
              </td>
            </template>
            <template #no-items-view>
              <div></div>
            </template>
          </CDataTable>
      </CCard>
</template>

<script>
import usersData from "./UsersDataEdit";
export default {
  
  name: "Users",
  data: () => ({
    items: usersData,
    isLoading: false,
    activePage: 1,
  }),

  computed: {
    fields: vm =>[
      { key: "username", label: vm.$i18n.t("message.usrname"), _classes: "font-weight-bold" },
      { key: "pc_name", label: vm.$i18n.t("message.pcname") },
      { key: "cpu", label: vm.$i18n.t("message.cpu") },
      { key: "ram", label: vm.$i18n.t("message.ram") },
      { key: "storage", label: vm.$i18n.t("message.hdddrive") },
      { key: "capacity", label: vm.$i18n.t("message.storall") },
      { key: "free_space", label: vm.$i18n.t("message.storremain") },
      { key: "storage_type", label: vm.$i18n.t("message.drivetype") },
    ],
  },
  

  watch: {
    $route: {
      immediate: true,
      handler(route) {
        if (route.query && route.query.page) {
          this.activePage = Number(route.query.page);
        }
      },
    },
  },
  methods: {
    pageChange(val) {
      this.$router.push({ query: { page: val } });
    },
    getBadge(status) {
      return status === "Active"
        ? "success"
        : status === "SSD"
        ? "primary"
        : status === "HDD"
        ? "warning"
        : status === "Banned"
        ? "danger"
        : "primary";
    },
  },
};
</script>
