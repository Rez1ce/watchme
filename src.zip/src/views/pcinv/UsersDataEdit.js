const usersData = [
  { username: 'Samppa Nori', pc_name: 'WS21', cpu: 'amd x64', ram: '10000', storage: 'ZHVBHJBSKD', capacity: '12341234', free_space: '44444', storage_type: 'HDD' },
  { username: 'Aulus Agmundr', pc_name: 'WS3363', cpu: 'intel x64', ram: '6456', storage: 'ZHVBHJBSKD', capacity: '1231235', free_space: '234666', storage_type: 'SSD' },
  { username: 'Chetan Mohamed', pc_name: 'WS335', cpu: 'intel x64', ram: '234234', storage: 'ZHVBHJBSKD', capacity: '2345', free_space: '643634', storage_type: 'SSD'},
  { username: 'Derick Maximinus', pc_name: 'WS24', cpu: 'amd x64', ram: '7456', storage: 'ZHVBHJBSKD', capacity: '234525', free_space: '234345', storage_type: 'HDD'},
  { username: 'Friderik Dávid', pc_name: 'WS22', cpu: 'amd x64', ram: '52345', storage: 'ZHVBHJBSKD', capacity: '12341234', free_space: '12223', storage_type: 'HDD'},
  { username: 'Quintin Ed', pc_name: 'WS33457', cpu: 'intel x64', ram: '32452', storage: 'S#SDFSRS##', capacity: '2352123', free_space: '2346', storage_type: 'SSD'},
  { username: 'Enéas Kwadwo', pc_name: 'WSt436', cpu: 'amd x64', ram: '10000', storage: 'fhdtxx3223', capacity: '5435346', free_space: '53452', storage_type: 'HDD'},
  { username: 'Quintin Ed', pc_name: 'WS357', cpu: 'intel x64', ram: '4334', storage: 'S#SDFSRS##', capacity: '2311234', free_space: '6343', storage_type: 'SSD'},
  { username: 'Enéas Kwadwo', pc_name: 'WS26', cpu: 'amd x64', ram: '6554', storage: 'fhdtxx3223', capacity: '324563241', free_space: '5345', storage_type: 'HDD'},
  { username: 'Eustorgios Amulius', pc_name: 'WS333', cpu: 'intel x64', ram: '4576', storage: 'SDFSDGH', capacity: '23563243', free_space: '234653', storage_type: 'SSD'},
  { username: 'Pompeius René', pc_name: 'WS22221', cpu: 'amd x64', ram: '3224', storage: 'ZHVBHJBSKD', capacity: '53465472', free_space: '52346', storage_type: 'HDD'},
  { username: 'Micheal Mercur', pc_name: 'WS211', cpu: 'amd x64', ram: '7866', storage: 'ZHVBHJBSKD', capacity: '345445', free_space: '43234', storage_type: 'HDD'},
]

export default usersData


