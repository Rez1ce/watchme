<template>

      <CCard bodyWrapper>
          <CDataTable
            hover
            striped
            :loading="isLoading"
            :items="items"
            :fields="fields"
            :items-per-page="20"
            :no-items-view="null"
            :active-page="activePage"
            :pagination="{ doubleArrows: false, align: 'center' }"
            @page-change="pageChange"
          >
            <template #status="data">
              <td>
                <CBadge :color="getBadge(data.item.status)">
                  {{ data.item.status }}
                </CBadge>
              </td>
            </template>
            <template #no-items-view>
              <div></div>
            </template>
          </CDataTable>
      </CCard>

</template>

<script>
export default {
  name: "Users",
  data: () => ({
    items: [],

    isLoading: false,
    activePage: 1,
  }),
  watch: {
    $route: {
      immediate: true,
      handler(route) {
        if (route.query && route.query.page) {
          this.activePage = Number(route.query.page);
        }
      },
    },
  },
  computed: {
      fields: vm =>[
      { key: "0", label: vm.$i18n.t("message.usrname"), _classes: "font-weight-bold" },
      { key: "1", label: vm.$i18n.t("message.lastlog") },
      { key: "2", label: vm.$i18n.t("message.lastpassch") },
    ],
  },
  methods: {
    pageChange(val) {
      this.$router.push({ query: { page: val } });
    },
    fetch() {
      this.isLoading = true;
      this.$http
        .get("http://10.5.37.89:8000/loginfo")
        .then((response) => {
          this.items = response.data.log_data;
        })
        .catch((error) => (this.err = error.response.data.detail))
        .finally(() => (this.isLoading = false));
    },
  },
  created() {
    this.fetch();
  },
};
</script>
