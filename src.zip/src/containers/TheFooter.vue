<template>
  <CFooter :fixed="false">

  </CFooter>
</template>

<script>
export default {
  name: 'TheFooter'
}
</script>
