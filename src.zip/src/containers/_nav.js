export default (i18nProvider) => [
  {
    _name: 'CSidebarNav',
    _children: [
      {
        _name: 'CSidebarNavItem',
        name: i18nProvider.t('message.dashboard'),
        to: '/dashboard',
        icon: 'cil-speedometer',
      },
      {
        _name: 'CSidebarNavTitle',
        _children: [i18nProvider.t('message.mon')],
      },
      {
        _name: 'CSidebarNavItem',
        name: i18nProvider.t('message.activmon'),
        to: { name: 'Dev'},
        icon: 'cilCursor'
      },
      {
        _name: 'CSidebarNavItem',
        name: i18nProvider.t('message.pcin'),
        to: { name: 'Pcinv'},
        icon: 'cilCog'
      },
            {
        _name: 'CSidebarNavItem',
        name: i18nProvider.t('message.usrlog'),
        to: { name: 'Log'},
        icon: 'cil-grid'
      },
      {
        _name: 'CSidebarNavItem',
        name: '',
        to: { name: 'Workday'},
        icon: 'cil-code'
      },
     
    ]
  }
]