<template>
  <CHeader fixed with-subheader light>
    <CToggler
      in-header
      class="ml-3 d-lg-none"
      @click="$store.commit('toggleSidebarMobile')"
    />
    <CToggler
      in-header
      class="ml-3 d-md-down-none"
      @click="$store.commit('toggleSidebarDesktop')"
    />
    <CHeaderBrand class="mx-auto d-lg-none" to="/">
      <CIcon name="logo" height="48" alt="Logo" />
    </CHeaderBrand>
    <CHeaderNav class="d-md-down-none mr-auto">
      <CHeaderNavItem class="px-3">
        <CHeaderNavLink to="/dashboard">
          {{ $t("message.dashboard") }}
        </CHeaderNavLink>
      </CHeaderNavItem>
    </CHeaderNav>
    <CHeaderNav class="mr-4">
      <div class="locale">
        <CDropdown size="sm" :caret="false" :v-model="locale">
          <template #toggler-content>
            <CIcon name="cilTranslate" />
          </template>
          <CDropdownItem @click="$i18n.locale = 'ru-RU'"
            ><CIcon name="cifRu" />Русский</CDropdownItem
          >
          <CDropdownItem @click="$i18n.locale = 'en-US'"
            ><CIcon name="cifUs" />English</CDropdownItem
          >
          <CDropdownItem
            :disabled ="true"
            @click.prevent="
              playSound(
                'https://5music.me/get-track/aHR0cHM6Ly9tdXNpY2QubXljZG4ubWUvdjAvc3RyZWFtP2lkPXYwXzEwMDU2MDIwNDQ5XzJfMSZjaWQ9djBfMTAwNTYwMjA0NDlfMl8xJmZpZD0xMjMwNjAyODczMzc1NzUmdWlkPTY1MjFiYjBjMjg3ZTAwMDE2NzQxYTNkM2ZhOGQ4YjZhJnNpZD1kNmQ0NTQzYmZmZjQyNGVkOWFlZGQ1ZDA2MDMwNGM2NDNhNTU5YzY0OTFkMDhhYWVkM2UyYTk2NjkyMTg1YWJjZmNkYmZkNzBlNTYwN2Q2YWFkYWRkNDBlMTdkM2ZmOGY5ZDI0ZjEzMDk5YmU5NDQxYmI5ZWI3NmIzOGJmYTYwZSZ0cz0xNjE1NTQwNzY2MjQxJm1kNT05N2FkNWU1OTMwNjYwNmY0ZmUwZDAzMzEwMTIyMTE5MSZjbGllbnRIYXNoPTE5NzIwMTE5ODMzMjEzMjEzMTI0MzIxMzIxMzIxMzEyOTE0MzI3NzEzMzIzNTEyNDMyMDM4MTIyNzE4MzIwMTQ1OTk5NTAyODQxNjUxOTEyMTMyMTMyMTMyMTMxNzk=/Mexican+Music+Factory+%E2%80%93+Fiesta.mp3'
              )
            "
            ><CIcon name="cifMx" />Mexico</CDropdownItem
          >
        </CDropdown>
      </div>
      <CHeaderNavItem class="d-md-down-none mx-2">
        <CHeaderNavLink>
          <CIcon name="cil-bell" />
        </CHeaderNavLink>
      </CHeaderNavItem>
      <CHeaderNavItem class="d-md-down-none mx-2">
        <CHeaderNavLink>
          <CIcon name="cil-list" />
        </CHeaderNavLink>
      </CHeaderNavItem>
      <CHeaderNavItem class="d-md-down-none mx-2">
        <CHeaderNavLink>
          <CIcon name="cil-envelope-open" />
        </CHeaderNavLink>
      </CHeaderNavItem>
      <TheHeaderDropdownAccnt />
    </CHeaderNav>

  </CHeader>
</template>

<script>
import TheHeaderDropdownAccnt from "./TheHeaderDropdownAccnt";

export default {
  name: "TheHeader",
  data() {
    return { locale: "en-US" };
  },
  components: {
    TheHeaderDropdownAccnt,
  },
  methods: {
    playSound(sound) {
      if (sound) {
        var audio = new Audio(sound);
        audio.play();
      }
    },
  },
};
</script>
