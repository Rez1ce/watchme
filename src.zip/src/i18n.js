import Vue from 'vue'
import VueI18n from 'vue-i18n'
import Formatter from './formatter'

Vue.use(VueI18n)

const locale = 'en-US' // default locale
const formatter = new Formatter({ locale })

export default new VueI18n({
  locale,
  formatter,

  messages: {
    'en-US': {
      message: {
        hello: 'hello!!',
        date: 'Date',
        startday: 'Start of working day',
        endday: 'End of working day',
        activetime: 'Active time',
        inactivetime: 'Inactive time',
        progressexplgood: 'Active time on PC',
        progressexplbad: 'Inactive time on PC',
        processtime: 'Program time',
        bizproc: 'Business-process time',
        activefeed: 'Activity feed',
        proc: 'Process',
        time: 'Time',
        condition: 'Condition',
        buttchoose: 'Choose',
        dashboard: 'Dashboard',
        activmon: 'Activity monitor',
        usrlog: 'User login info',
        mon: 'monitoring',
        usrname: 'Name',
        pcname: 'Workstation name',
        cpu: 'Processor',
        ram: 'RAM memory',
        hdddrive: 'Storage device',
        storall: 'Storage volume (in total)',
        storremain: 'Storage volume (remained)',
        drivetype: 'Drive type',
        usrsm: 'Users',
        activsm: 'Activity',
        pcin: 'Inventory',
        lastpassch: "Last password change",
        lastlog: 'Last logon',
        totalTime: 'Total time',

      }
    },
    'ru-RU': {
      message: {
        hello: 'Привет!!',
        date: 'Дата',
        startday: 'Начало рабочего дня',
        endday: 'Конец рабочего дня',
        activetime: 'Активное время',
        inactivetime: 'Не активное время',
        progressexplgood: 'Активное время за пк',
        progressexplbad: 'Неактивное время за пк',
        processtime: 'Время по программам',
        bizproc: 'Время по бизнес-процессам',
        activefeed: 'Лента активности',
        usrname: 'Имя',
        pcname: 'Имя компьютера',
        cpu: 'Процессор',
        ram: 'Оперативная память',
        hdddrive: 'Дисковый накопитель',
        storall: 'Объём накопителя (всего)',
        storremain: 'Объём накопителя (осталось)',
        drivetype: 'Тип накопителя',
        proc: 'Процесс',
        time: 'Время',
        condition: 'Состояние',
        buttchoose: 'Выбрать',
        dashboard: 'Дашборд',
        activmon: 'Монитор активности',
        usrlog: 'Информация о входах',
        mon: 'Мониторинг',
        usrsm: 'Пользователи',
        activsm: 'Активность',
        pcin: 'Инвентаризация',
        lastpassch: 'Последняя смена пароля',
        lastlog: 'Последний вход в систему', 
        totalTime: 'Всего времени'
      }
    }
  }
})
